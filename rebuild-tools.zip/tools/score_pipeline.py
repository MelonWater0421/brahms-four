#!/usr/bin/env python3
"""Extract sounding-pitch orchestral parts and approximate recording alignment.
Sources: OpenScore Orchestra CC0 scores (see sources.json).
Requires music21, numpy, scipy, librosa. Never derives instrument labels from piano MIDI.
"""
import json,sys
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parent.parent
CACHE=ROOT/'tools'/'score-cache'; CACHE.mkdir(exist_ok=True)
def extract(i):
 from music21 import converter
 s=converter.parse(ROOT/f'tools/scores/movement-{i}.mxl').toSoundingPitch()
 bars=[{'bar':m.number-(i==1),'q':float(m.offset),'length':float(m.duration.quarterLength)} for m in s.parts[0].getElementsByClass('Measure')]
 parts=[]
 for p in s.parts:
  name=p.partName
  group='horns' if 'Horn' in name else 'brass' if any(k in name for k in ('Trumpet','Trombone')) else 'perc' if name in ('Timpani','Triangle') else 'strings' if any(k in name for k in ('Violin','Viola','Violoncello','Contrabass')) and name!='Contrabassoon' else 'winds'
  # Corrections checked against Breitkopf full score, PDF p34: Bassoon 1 only at II 41–46.
  if i==2 and name=='Bassoon 2':
   for m in p.getElementsByClass('Measure'):
    if 41<=m.number<=46:
     for n in list(m.recurse().notes): n.activeSite.remove(n)
  clean=p.stripTies(inPlace=False);notes=[]
  for n in clean.flatten().notes:
   if not n.duration.quarterLength: continue # grace-note realization is not represented in this teaching reduction
   pitches=n.pitches if hasattr(n,'pitches') else []
   if not pitches and name=='Triangle': pitches=[None]
   for pitch in pitches:
    notes.append({'q':round(float(n.offset),6),'dur':round(float(n.duration.quarterLength),6),'midi':int(pitch.midi) if pitch else 81,'label':pitch.nameWithOctave.replace('-','♭').replace('#','♯') if pitch else '△'})
  parts.append({'id':str(p.id),'name':name,'group':group,'notes':notes})
 d={'movement':i,'bars':bars,'endQ':bars[-1]['q']+bars[-1]['length'],'parts':parts}
 (CACHE/f'm{i}.json').write_text(json.dumps(d,ensure_ascii=False))
 print('Extracted',i,len(bars),'bars',len(parts),'parts',sum(len(p['notes']) for p in parts),'notes',flush=True)
 return d

def align(i,d):
 import librosa
 from scipy.spatial.distance import cdist
 feature=CACHE/f'audio{i}.npz'
 if feature.exists():
  a=np.load(feature);cqt=a['cqt'];rms=a['rms'];duration=float(a['duration']);tuning=float(a['tuning'])
 else:
  y,sr=librosa.load(ROOT/f'assets/movement-{i}.mp3',sr=22050)
  duration=len(y)/sr;tuning=float(librosa.estimate_tuning(y=y,sr=sr))
  cqt=librosa.feature.chroma_cqt(y=y,sr=sr,hop_length=2205,tuning=tuning,norm=2)
  rms=librosa.feature.rms(y=y,frame_length=4096,hop_length=2205)[0]
  np.savez_compressed(feature,cqt=cqt,rms=rms,duration=duration,tuning=tuning)
 # Leading room noise is excluded using waveform-inspected first musical attacks.
 start_sec={1:4.2,2:4.2,3:3.1,4:4.6}[i]; start_frame=round(start_sec*10)
 cqt=cqt[:,start_frame:];rms=rms[start_frame:]
 # Uniform quarter-note grid preserves pickup and changed meter; 10 Hz average density.
 n=int((duration-start_sec)*10);qs=np.linspace(0,d['endQ'],n,endpoint=False);step=d['endQ']/n
 chroma=np.zeros((12,n),dtype=np.float32);energy=np.zeros(n);onset=np.zeros(n)
 for p in d['parts']:
  if p['name']=='Triangle':continue
  for note in p['notes']:
   left=max(0,int(note['q']/step));right=min(n,int(np.ceil((note['q']+note['dur'])/step)))
   chroma[note['midi']%12,left:right]+=1
   energy[left:right]+=1;onset[left]+=1
 chroma/=np.maximum(1e-8,np.linalg.norm(chroma,axis=0))
 log=np.log1p(rms*100);log=(log-log.min())/(np.ptp(log)+1e-8)
 energy=np.log1p(energy);energy=(energy-energy.min())/(np.ptp(energy)+1e-8)
 onset=np.clip(onset/(np.percentile(onset,98)+1e-8),0,1)
 novelty=np.maximum(0,np.diff(log,prepend=log[0]));novelty=np.clip(novelty/(np.percentile(novelty,98)+1e-8),0,1)
 m=min(cqt.shape[1],len(log));X=np.vstack([chroma,energy*.3,onset*.15]);Y=np.vstack([cqt[:,:m],log[:m]*.3,novelty[:m]*.15])
 X/=np.maximum(1e-8,np.linalg.norm(X,axis=0));Y/=np.maximum(1e-8,np.linalg.norm(Y,axis=0))
 C=np.asarray(1-X.T@Y,dtype=np.float32)
 _,wp=librosa.sequence.dtw(C=C,step_sizes_sigma=np.array([[1,1],[1,2],[2,1],[1,3],[3,1]]),weights_mul=np.array([1,1.05,1.05,1.15,1.15]),global_constraints=True,band_rad=.22)
 wp=wp[::-1];unique,idx=np.unique(wp[:,0],return_index=True)
 times=np.interp(qs,qs[unique],wp[idx,1]*.1+start_sec)
 starts=np.interp([b['q'] for b in d['bars']],qs,times)
 starts[0]=start_sec
 for k in range(1,len(starts)): starts[k]=max(starts[k],starts[k-1]+.1)
 out={'duration':duration,'tuningSemitones':tuning,'method':'orchestral sounding-pitch chroma DTW; approximate, not manual beat alignment','bars':[dict(b,sec=round(float(t),3)) for b,t in zip(d['bars'],starts)]}
 (CACHE/f'alignment{i}.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
 print('Aligned',i,round(duration,2),'seconds; first',starts[:4],flush=True)

if __name__=='__main__':
 for i in range(1,5):
  f=CACHE/f'm{i}.json';d=json.loads(f.read_text()) if f.exists() else extract(i)
  if not (CACHE/f'alignment{i}.json').exists():align(i,d)
