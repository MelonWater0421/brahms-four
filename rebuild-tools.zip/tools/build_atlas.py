#!/usr/bin/env python3
"""Compile reviewed prose, orchestral score excerpts, and approximate audio mapping."""
import json,shutil,re
from pathlib import Path
import mido
ROOT=Path(__file__).resolve().parent.parent
CACHE=ROOT/'tools/score-cache'
SCORE='https://s9.imslp.org/files/imglnks/usimg/b/bb/IMSLP317596-PMLP01617-Brahms_Werke_Band_2_Breitkopf_JB_4_Op_98_scan.pdf'
SOURCE='https://github.com/MarkGotham/Hauptstimme/tree/main/data/Brahms%2C_Johannes/Symphony_No.4%2C_Op.98'
COLORS=['#f59e0b','#60a5fa','#34d399','#c084fc','#fb7185']
NAMES={'Violin 1':'第一小提琴','Violin 2':'第二小提琴','Viola':'中提琴','Violoncello':'大提琴','Contrabass':'低音提琴','Contrabassoon':'低音巴松','Timpani':'定音鼓','Triangle':'三角铁','Piccolo':'短笛'}
for eng,zh in [('Flute','长笛'),('Oboe','双簧管'),('A Clarinet','单簧管'),('B♭ Clarinet','单簧管'),('B-flat Clarinet','单簧管'),('B♭ Trumpet','小号'),('Bassoon','巴松'),('E Horn','圆号'),('C Horn','圆号'),('F Horn','圆号'),('E Trumpet','小号'),('C Trumpet','小号'),('Trombone','长号')]:
 for n in range(1,5):NAMES[f'{eng} {n}']=zh+str(n)
def program(name):
 for key,p in [('Piccolo',72),('Flute',73),('Oboe',68),('Clarinet',71),('Bassoon',70),('Contrabassoon',70),('Horn',60),('Trumpet',56),('Trombone',57),('Timpani',47),('Violin',40),('Viola',41),('Violoncello',42),('Contrabass',43)]:
  if key in name:return p
 return 0

def write_midi(tracks,bpm,total,path):
 mid=mido.MidiFile(ticks_per_beat=480)
 meta=mido.MidiTrack();mid.tracks.append(meta);meta.append(mido.MetaMessage('set_tempo',tempo=mido.bpm2tempo(bpm),time=0))
 for ti,t in enumerate(tracks):
  ch=ti if ti<9 else ti+1
  tr=mido.MidiTrack();mid.tracks.append(tr)
  tr.append(mido.MetaMessage('track_name',name=t['sourcePart'],time=0));tr.append(mido.Message('program_change',program=t['program'],channel=ch,time=0))
  events=[]
  for n in t['notes']:
   events.extend([(round(n['start']*480),1,n['midi']),(round((n['start']+n['dur'])*480),0,n['midi'])])
  last=0
  for tick,on,pitch in sorted(events):
   tr.append(mido.Message('note_on' if on else 'note_off',note=pitch,velocity=70 if on else 0,channel=ch,time=tick-last));last=tick
  tr.append(mido.MetaMessage('end_of_track',time=max(0,round(total*480)-last)))
 mid.save(path)

def excerpt(d,a,i,j,title,start,end,partnames,desc,bpm):
 bybar={b['bar']:b for b in d['bars']};times={b['bar']:b['sec'] for b in a['bars']}
 q0=bybar[start]['q'];q1=bybar[end+1]['q'] if end+1 in bybar else d['endQ'];tracks=[]
 for name in partnames:
  part=next(p for p in d['parts'] if p['name']==name);notes=[]
  for n in part['notes']:
   l=max(q0,n['q']);r=min(q1,n['q']+n['dur'])
   if r>l:notes.append({'start':round(l-q0,5),'dur':round(r-l,5),'midi':n['midi'],'label':n['label']})
  if notes:tracks.append({'name':NAMES.get(name,name),'sourcePart':name,'sourcePartId':part['id'],'program':program(name),'sub':'实音 · 所选声部完整节选','wave':'triangle','color':COLORS[len(tracks)%5],'notes':notes})
 assert tracks
 file=f'assets/m{i}-excerpt{j+1}.mid';write_midi(tracks,bpm,q1-q0,ROOT/file)
 return {'name':title,'coord':f'第{start}–{end}小节','realJumpSec':times[start],'bpm':bpm,'totalBeats':q1-q0,'desc':desc,'provenance':f'OpenScore Orchestra CC0 · 第{start}–{end}小节'+('（0为弱起）' if start==0 else '')+' · 实音节选','midi':file,'scoreBars':[start,end],'tracks':tracks}

EXCERPTS={
1:[('三度链',0,8,['Violin 1','Viola','Violoncello','Flute 1'],'先听小提琴，再加入低处的琶音与长笛回应。开头两音是 B–G；后面的 E 向上到 C 是小六度。',116),('号角型的问答',53,56,['Oboe 1','A Clarinet 1','C Horn 3','Violin 1'],'管乐先说，小提琴随后回答。“号角型”描述节奏与姿态，不等于一直由小号领奏。',116),('大提琴第二主题',57,64,['Violoncello','E Horn 1','Violin 1','Viola'],'B小调的歌唱悬在拨弦上。固定合成音色只呈现音高和节奏；拨弦与运弓的区别请回原声听。',116),('放大的主题回归',246,251,['Flute 1','A Clarinet 1','Violin 1','Violoncello'],'再现从246开始：木管把主题放大成较长的音值，弦乐继续流动。与第一段对照。',100)],
2:[('两支圆号交给木管',1,5,['C Horn 3','C Horn 4','Oboe 1','A Clarinet 1','Violin 1'],'第1小节两支圆号同奏，第2小节木管加入，第4小节单簧管接唱，第5小节弦乐拨弦。',66),('大提琴与小提琴',41,44,['Violoncello','Violin 1','Bassoon 1','Viola'],'先跟大提琴的连贯旋律，再加入上方更快的小提琴装饰。第一巴松支撑长音。',66),('歌唱转到小提琴',88,91,['Violin 1','Violin 2','Viola','Violoncello'],'与41–44比较：同一条歌移到第一小提琴，其他弦乐形成和声层。',66),('号角回归的背景',113,116,['C Horn 3','C Horn 4','Violoncello','Viola','Oboe 1'],'圆号重提开头旋律；中低弦的运动使同一呼唤获得不同背景。',66)],
3:[('开场的节奏',1,4,['Violin 1','Piccolo','F Horn 1','Timpani'],'把高处的旋律与圆号、定音鼓的支点分开听；谱面是2/4拍。',132),('Grazioso的轻巧',52,59,['Violin 1','Violin 2','Viola','Flute 1'],'把第一小提琴的连线与短音伴奏分开，再听木管怎样加入。',132),('Poco meno presto',181,188,['C Horn 3','Bassoon 1','Violoncello'],'速度稍缓，听圆号与巴松的线条，弦乐怎样留出空间；拍号仍是2/4。',112),('轻声里的脉搏',282,289,['Timpani','Violin 1','Bassoon 1','Contrabass'],'先听定音鼓，再加上旋律片段，听弱奏怎样保持推动力。',132)],
4:[('八小节主题',1,8,['Flute 1','Oboe 1','Trombone 1','Trombone 3'],'先独听长笛逐步上行、再跳回的线条，再加入低处和声。主题并不是从头到尾只在低音。',108),('长笛独奏',97,104,['Flute 1','Violin 1','Viola','E Horn 1'],'第12变奏转为3/2拍。上方长笛的旋律与下方支撑分开听；这里不是长笛、双簧管的同一条复制音轨。',108),('长号与和声',113,120,['Trombone 1','Trombone 2','Trombone 3','Viola','Violoncello'],'先听长号之间的和声，再加入中提琴、大提琴的分解音型。长号在终曲开头就已出现，此处是另一种用法。',108),('三连音由低到高',177,184,['Violoncello','Viola','Violin 2','Violin 1'],'按大提琴、中提琴、第二小提琴、第一小提琴的顺序打开声部，听三连音型逐次进入。',108)]}

old=ROOT/'tools/original-data.json'
if not old.exists():
 s=(ROOT/'data.js').read_text();old.write_text(json.dumps(json.JSONDecoder().raw_decode(s[s.index('{'):])[0],ensure_ascii=False))
original=json.loads(old.read_text());meta=original['metadata']
meta.update(storageKey='brahms-four-score2',pageTitle_zh='Brahms 4 · 跟着总谱听勃拉姆斯第四',heroSubtitle_zh=' · 总谱导览 · 动机实验室',timingRef_zh='总谱自动对齐 · ≈',scoreNote_zh='节点的小节、排练号与主要乐器关系依据 Breitkopf & Härtel 扫描总谱核对。节选音符来自 OpenScore Orchestra 的管弦乐录入；不等同于逐音校勘的批判版本。',dtwNote_zh='时间由管弦乐谱的实音色度与本地录音自动对齐，属于近似定位；持续音、休止及重复音型附近可能偏移。可在段落下方人工校准。',synthIntro_zh='每条轨道对应真实总谱声部，已换算为实音。可静音、独奏，再回到原声比较。',sourcesBody_zh='四乐章按印刷总谱编号：440（另有弱起）、118、357、311小节。第I乐章的弱起记为0。排练号以链接的旧全集总谱为准；OpenScore数字录入用于音符节选与谱面活动提示。已修正II 41–46小节第二巴松的重复录入。',sourcesInterp_zh='沿用项目现有、标注为 Carlos Kleiber / Wiener Philharmoniker（DG 1980）的四条录音。网页时长与定位针对这些文件；没有把文件标记当作母带来源鉴定。页面载入不自动播放；自选音轨只在本机浏览器中使用。',finaleComplete_zh='全曲结束。可以回到终曲开头，比较八小节主题与尾声之间的关系。',finaleCta_zh='重听终曲尾声',hornsLabel_zh='圆号',percLabel_zh='打击乐',settingsIntro_zh='内置项目的四乐章录音，页面打开时保持暂停。也可以使用自己的音轨；文件只在本次浏览器会话中读取，不会上传。')
# Avoid old translated factual claims surviving language fallbacks.
for k in list(meta):
 if k.endswith('_en'):del meta[k]
D={'metadata':meta,'movements':[],'sources':[{'title':'Breitkopf & Härtel · 勃拉姆斯全集总谱','url':SCORE,'note':'导览节点、排练号及配器的主要核对依据；链接中的页码为PDF页。'},{'title':'OpenScore Orchestra · 四乐章数字总谱','url':SOURCE,'note':'谱面数据CC0；本项目只提取音符与乐器信息，未复用其CC-BY-SA分析标注。'},{'title':'OpenScore Orchestra · 授权与项目说明','url':'https://github.com/MarkGotham/Hauptstimme','note':'数字录入可能存在独奏/同奏拆分等差异。'},{'title':'Deutsche Grammophon · Kleiber / Brahms 4','url':'https://www.deutschegrammophon.com/en/catalogue/products/brahms-symphony-no-4-kleiber-8021','note':'官方唱片资料。'}]}
for i in range(1,5):
 d=json.loads((CACHE/f'm{i}.json').read_text());a=json.loads((CACHE/f'alignment{i}.json').read_text());r=json.loads((ROOT/f'tools/research/movement{i}.json').read_text());times={b['bar']:b['sec'] for b in a['bars']}
 events=r.get('stages',r.get('events'));m=original['movements'][i-1]
 for k in list(m):
  if k.endswith('_en'):del m[k]
 m.update(title=['流动的三度链','号角与歌唱','明亮的节奏','主题与三十变奏'][i-1],navLabel=['Allegro','Andante','Giocoso','Finale'][i-1],introduction=r.get('intro',r.get('introduction','')),mission=r.get('mission',''),duration=round(a['duration'],3),barCount=d['bars'][-1]['bar'],originalTitle=['Allegro non troppo · E minor · 440小节＋弱起','Andante moderato · E major · 118小节','Allegro giocoso · C major · 357小节','Allegro energico e passionato · E minor · 311小节'][i-1],timing='approximate',audioMatched=False,stages=[],motifs=[],synthModes=[],barEvents=[])
 for j,b in enumerate(a['bars']):
  groups={k:[] for k in ['strings','winds','horns','brass','perc']}
  for part in d['parts']:
   if any(n['q']<b['q']+b['length']-.0001 and n['q']+n['dur']>b['q']+.0001 for n in part['notes']):groups[part['group']].append(NAMES.get(part['name'],part['name']))
  m['barEvents'].append({'bar':b['bar'],'sec':b['sec'],'groups':groups})
 for j,e in enumerate(events):
  bar=e['bar'];end=events[j+1]['bar']-1 if j+1<len(events) else m['barCount'];label=('弱起–'+str(end) if bar==0 else f'{bar}–{end}')+' 小节'
  if e.get('rehearsal'):label+=' · 排练 '+e['rehearsal']
  if i==1:act=1+sum(bar>=n for n in [145,246,394]);actName=['呈示部','展开部','再现部','尾声'][act-1]
  elif i==4:act=1+sum(bar>=n for n in [97,129,253]);actName=['主题与变奏1–11','变奏12–15 · 舒展','变奏16–30 · 回流','尾声'][act-1]
  else:act=1;actName=['','号角与歌唱','节奏与对照'][i-1]
  stage={'id':f'm{i}-b{bar}','bar':bar,'start':0 if j==0 else times[bar],'timing':'reference','act':act,'actName':actName,'title':e['title'],'desc':e['desc'],'focus':e.get('focus',''),'color':COLORS[(act-1)%5],'blocks':[],'cues':[],'choirs':{k:{'active':True,'role':v} for k,v in e.get('roles',{}).items() if v and '休止' not in v and '没有长号' not in v},'score':{'label':label,'page':e['sourcePage'],'url':SCORE+'#page='+str(e['sourcePage']),'edition':meta['edition']}}
  for match in re.finditer(r'第(\d+)小节',e['desc']):
   cuebar=int(match.group(1))
   if bar<cuebar<=end and not any(c.get('bar')==cuebar for c in stage['cues']):
    following=e['desc'][match.end():].split('。')[0].split('；')[0]
    stage['cues'].append({'bar':cuebar,'sec':times[cuebar],'label':f'第{cuebar}小节 · '+following[:32]})
  stage['cues'].sort(key=lambda c:c['bar'])
  m['stages'].append(stage)
 for j,args in enumerate(EXCERPTS[i]):
  mode=excerpt(d,a,i,j,*args);m['synthModes'].append(mode)
  motif={'id':f'm{i}-motif{j}','name':args[0],'earprint':args[4] if False else mode['desc'],'color':COLORS[j],'audioStart':mode['realJumpSec'],'stageIndex':max(k for k,s in enumerate(m['stages']) if s['bar']<=args[1])}
  m['motifs'].append(motif)
  # Tag locations in/around the excerpt, rather than invent thematic recurrence labels.
  for s in m['stages']:
   if s['bar']<=args[2] and (m['stages'][m['stages'].index(s)+1]['bar'] if m['stages'].index(s)+1<len(m['stages']) else m['barCount']+1)>args[1]:s['blocks'].append(motif['id'])
 if i==4:m['codaStageId']='m4-b253'
 m['next']='完成这一章后，可以继续下一章；页面会保留相同的聆听方式。'
 D['movements'].append(m)
D['metadata']['totalStages']=sum(len(m['stages']) for m in D['movements'])
D['glossary']=[{'term':a,'definition':b} for a,b in [('动机','容易辨认的短小音程或节奏。它可以更换乐器、调性、音值和伴奏，不必每次原样出现。'),('声部与音色','声部是一条音乐线；乐器是发声者。同一条线可以由多件乐器同奏，一件乐器也可能暂时从旋律变成伴奏。'),('实音','实际响起的音高。单簧管、圆号、低音提琴等在谱上写出的音与实音可能不同；实验室统一显示实音。'),('再现部','奏鸣曲式中，先前的主题在展开后重新建立联系的区域。第一乐章第246小节已开始放大的主题再现，259恢复原先流动的节奏。'),('帕萨卡利亚与变奏','终曲围绕八小节框架写出主题与30次变奏，再接尾声。固定材料可能出现在上声部、内声部或低音，不要只盯最低的一条线。'),('排练号','总谱上的字母或数字路标，便于乐团定位。本页采用链接扫描谱的排练字母；其他版本可能不同。'),('近似定位','总谱是音乐结构的坐标，秒数属于这份录音。自动对齐能帮助导航，却不能替代逐拍听辨；可用卡片下方的校准修正。')]]
D['threads']=[{'title':a,'summary':b} for a,b in [('从小材料听大结构','先在实验室辨认短句，再回录音听它怎样换到其他乐器。第一乐章的下行三度、号角节奏和大提琴歌唱，提供三条容易追踪的线。'),('比较两次出现','第二乐章把41小节的大提琴与88小节的小提琴并置；同一旋律换了音区、调性和背景，耳朵便能听到结构。'),('明亮的第三乐章','第三乐章以C大调和2/4拍形成鲜明对照。短笛、低音巴松与三角铁扩大色彩；181小节速度稍缓，199回到原速。'),('八小节如何容纳变化','终曲保留反复返回的框架，却不断改变旋律、节奏和配器。97–128小节放宽为3/2，129回3/4，253开始尾声。')]]
(ROOT/'data.js').write_text('window.BRAHMS_DATA = '+json.dumps(D,ensure_ascii=False,separators=(',',':'))+';\n')
(ROOT/'tools/sources.json').write_text(json.dumps(D['sources'],ensure_ascii=False,indent=2))
print('Built',D['metadata']['totalStages'],'stages;',sum(len(m['synthModes']) for m in D['movements']),'excerpts')
