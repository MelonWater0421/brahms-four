#!/usr/bin/env python3
import json
from pathlib import Path
import mido
P=Path(__file__).resolve().parent.parent
s=(P/'data.js').read_text();d=json.JSONDecoder().raw_decode(s[s.index('{'):])[0]
counts=[440,118,357,311]
for m in d['movements']:
 assert m['barCount']==counts[m['id']-1]
 assert all(a['start']<b['start'] for a,b in zip(m['stages'],m['stages'][1:]))
 assert all(a['sec']<b['sec'] for a,b in zip(m['barEvents'],m['barEvents'][1:]))
 assert m['stages'][-1]['start']<m['duration']
 for stage in m['stages']:
  assert stage['score']['url'].startswith('https://')
  for cue in stage['cues']:assert cue['sec']>stage['start'] and cue['bar']>stage['bar']
 for mode in m['synthModes']:
  midi=mido.MidiFile(P/mode['midi']);assert len(midi.tracks)==len(mode['tracks'])+1
  for t in mode['tracks']:
   assert t['sourcePartId'] and len(t['notes'])>0
   assert all(n['start']>=0 and n['dur']>0 and n['start']+n['dur']<=mode['totalBeats']+.0001 for n in t['notes'])
  assert abs(midi.length-mode['totalBeats']*60/mode['bpm'])<.01
  # Nothing is silently capped at 64; all selected note onsets are present through excerpt end.
  source=json.loads((P/f'tools/score-cache/m{m["id"]}.json').read_text())
  bs={b['bar']:b for b in source['bars']};start,end=mode['scoreBars'];q0=bs[start]['q'];q1=bs[end]['q']+bs[end]['length']
  for t in mode['tracks']:
   part=next(p for p in source['parts'] if p['id']==t['sourcePartId']);expected=sum(n['q']<q1 and n['q']+n['dur']>q0 for n in part['notes']);assert expected==len(t['notes'])
 print('PASS',m['id'],len(m['stages']),'stages',len(m['barEvents']),'bar events',len(m['synthModes']),'MIDI excerpts')
ii=d['movements'][1];iv=d['movements'][3]
assert ii['barEvents'][0]['groups']['horns']==['圆号3','圆号4']
assert not ii['barEvents'][0]['groups']['strings']
assert all(not b['groups']['strings'] for b in iv['barEvents'][:8])
assert '长号1' in iv['barEvents'][0]['groups']['brass']
assert [n['midi']%12 for n in iv['synthModes'][0]['tracks'][0]['notes']]==[4,6,7,9,10,11,11,4]
assert any(len(t['notes'])>64 for m in d['movements'] for mode in m['synthModes'] for t in mode['tracks'])
print('PASS targeted orchestration, full excerpt retention, theme pitches, and MIDI durations')
